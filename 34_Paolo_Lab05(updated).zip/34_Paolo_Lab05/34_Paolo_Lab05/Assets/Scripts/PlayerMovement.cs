﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class PlayerMovement : MonoBehaviour
{
    public float speed;
    public Rigidbody playerRigidbody;
    public Text Scoretext;
    public int score;
    // Start is called before the first frame update
    void Start()
    {
        int score = 0;

    }

    // Update is called once per frame
    void Update()
    {
        Scoretext.text = "coins collected : " + score;

        if(score == 4)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
    }

    void FixedUpdate()
    {
        float MoveHorizontal = Input.GetAxis("Horizontal");
        float MoveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(MoveVertical,0, MoveHorizontal);
        transform.Translate(movement * Time.deltaTime * speed);
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "coins")
        {
            Destroy(collision.gameObject);
            score++;

        }
        if (collision.gameObject.tag == "barricade")
        {
            SceneManager.LoadScene("lose");

        }
    }
}
